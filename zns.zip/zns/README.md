



Mass Looker ,it’s a console-based script created for massvoting (mass poll voting) and masslooking stories

# Features

  - Views Stories
  - Question Answer
  - Poll Voting
  - Emoji Slider
  
# Uses 
   - Unlimited real followers
   - Unlimited real likes
   - Increasing profile visits
   - Incredible reach
   
# Installation

MassLooker requires [PHP](https://www.php.net/) 5.6 to run.

```sh
Follow These Steps for Installation
$pkg install php
$pkg install git
$pkg install mc
$ git clone https://github.com/pedjazyzz/masslooker
$ cd masslooker
$ php login.php
$ php run.php
```

